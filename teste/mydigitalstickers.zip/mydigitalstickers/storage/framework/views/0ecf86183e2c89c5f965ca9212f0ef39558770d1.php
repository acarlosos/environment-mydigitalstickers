<?php $__env->startSection('title', 'Extrato do aluno'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Extrato do aluno</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('carteira.index')); ?>">Extrato do aluno</a>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-9">
        <div class="ibox ">
            <div class="ibox-content animated rollIn" id="ibox-content">
                <div id="vertical-timeline" class="vertical-container dark-timeline center-orientation">
                    <?php
                        $c = 0;
                    ?>

                        <?php $__currentLoopData = $AlunoCarteira; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $c++;
                            switch ($dados->Action) {
                                case 'Compra':
                                    $icon = 'fa fa-usd';
                                    break;
                                case 'Gerado':
                                    $icon = 'fa fa-snowflake-o';
                                    break;
                                case 'Troca':
                                    $icon = 'fa fa-exchange';
                                    break;
                                default:
                                    $icon = 'fa fa-briefcase';
                                    break;
                            }
                        ?>

                        <div class="vertical-timeline-block">
                            <div class="vertical-timeline-icon navy-bg">
                                <i class="<?php echo e($icon); ?>"></i>
                            </div>

                            <div class="vertical-timeline-content">
                                <?php if($dados->Action == 'Compra'): ?>
                                    <div class="alert alert-warning">
                                        <h5><?php echo e($dados->Action); ?></h5>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-success">
                                        <h5><?php echo e($dados->Action); ?></h5>
                                    </div>
                                <?php endif; ?>

                                <p>
                                    <button class="btn-primary dim btn-default-dim" type="button"><i class="fa fa-dollar"></i>
                                        <?php echo e($dados->QTD); ?>

                                    </button>
                                </p>
                                <p>
                                    <button class="btn-primary dim btn-default-dim" type="button"><i class="fa fa-user"></i>&nbsp;&nbsp;
                                        <?php echo e($dados->Aluno ?? $dados->Nome); ?>

                                    </button>

                                </p>
                                <span class="vertical-date">
                                    <p class="text-info"><?php echo e(\Carbon\Carbon::parse($dados->DT)->format('d/m/Y H:i:s')); ?></p>
                                </span>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($c == 0): ?>
                        <h3>Não há movimentações em sua carteira</h3>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <?php if(isset($AlunoCarteiraTot) && $AlunoCarteiraTot != ''): ?>
        <div class="widget style1 yellow-bg">
            <div class="row">
                <div class="col-4">
                    <i class="fa fa-dollar fa-5x"></i>
                </div>
                <div class="col-8 text-right">
                    <span> Total de Pontos </span>
                    <h2 class="font-bold"><?php echo e($AlunoCarteiraTot); ?></h2>
                </div>
            </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?> 



















<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/carteira/alunocarteira.blade.php ENDPATH**/ ?>