<?php $__env->startSection('title', 'Cadastrar Ponto'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Cadastrar Ponto</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('ponto.list')); ?>">Lista Ponto </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Cadastrar Ponto</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(action('PontoController@store')); ?>">
        <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="UsuarioEscolaID">Usuario Escola</label>
                    <select class="form-control" name="UsuarioEscolaID" >
                        <?php $__currentLoopData = $UsuarioEscolas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value ="<?php echo e($UsuarioEscola->UsuarioEscolaID); ?>">
                                <?php echo e($UsuarioEscola->Escola.' - '.$UsuarioEscola->UsuarioNome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="UsuarioEscolaID">Adicionar / Baixar Pontos</label>
                    <select class="form-control" name="PontoOperacao" >
                        <?php $__currentLoopData = $UsuarioEscolas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value ="1">+ / Adicionar</option>
                            <option value ="2">- / Baixar</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Pontos</label>
                    <input type="text" class="form-control" name="PontoQuantidade" id="validationCustom01" required >
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
            </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/ponto/ponto.blade.php ENDPATH**/ ?>