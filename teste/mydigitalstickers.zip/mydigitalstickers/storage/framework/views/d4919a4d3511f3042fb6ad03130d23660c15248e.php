<?php $__env->startSection('title', 'Editar Usuário'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Usuário</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('usuario.list')); ?>">Lista Usuário</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar Usuário</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('usuario/update/'.$usuario->UsuarioID)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="PerfilID">Perfil</label>
                <select class="form-control" name="PerfilID">
                    <?php $__currentLoopData = $usuario->Perfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($Perfil->PerfilID == $usuario->PerfilID): ?> selected <?php endif; ?> value="<?php echo e($Perfil->PerfilID); ?>"><?php echo e($Perfil->Perfil); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="validationCustom01">Login do Usuario</label>
                <input type="text" class="form-control" name="UsuarioLogin" id="validationCustom01" required <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioLogin)); ?>"<?php endif; ?> placeholder="Usuario" />
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Senha do Usuario</label>
                <input type="text" class="form-control" name="UsuarioSenha" />
            </div>
            <div class="form-group">
                <label for="validationCustom01">Nome do Usuario</label>
                <input type="text" class="form-control" name="UsuarioNome" id="validationCustom01" required <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioNome)); ?>"<?php endif; ?> />
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <label for="validationCustom01">Email</label>
                        <input type="text" class="form-control" name="UsuarioEmail" placeholder="Email" id="validationCustom01" required <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioEmail)); ?>"<?php endif; ?> />
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="validationCustom01">Celular</label>
                <input type="text" class="form-control" name="UsuarioCelular" id="campoCelular" maxlength="15" required <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioCelular)); ?>"<?php endif; ?> />
            </div>
            <div class="form-group">
                <label for="validationCustom01">Matrícula Usuário</label>
                <input type="text" class="form-control" name="UsuarioMatricula" id="validationCustom01" required <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioMatricula)); ?>"<?php endif; ?> />
            </div>
            <div class="form-group">
                <label for="Usuarios">Status</label>
                <select class="form-control" name="UsuarioStatus">
                    <option value="1" <?php if(isset($usuario) && $usuario->UsuarioStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                    <option value="2" <?php if(isset($usuario) && $usuario->UsuarioStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                    <option value="3" <?php if(isset($usuario) && $usuario->UsuarioStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTAtivacao) && $usuario->UsuarioDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTInativacao) && $usuario->UsuarioDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTBloqueio) && $usuario->UsuarioDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
<script>
        $("#campoCelular").mask("(99) 09999-9999");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuario/editar.blade.php ENDPATH**/ ?>