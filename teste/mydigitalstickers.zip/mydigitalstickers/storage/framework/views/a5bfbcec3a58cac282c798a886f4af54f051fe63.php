<?php $__env->startSection('title', 'Cadastro de informativo de acesso '); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Cadastro de informativo de acesso </h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('informativoacesso.list')); ?>">Lista informativo de acesso </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Cadastro de informativo de acesso </strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form role="form" method="post" action="<?php echo e(action('InformativoAcessoController@store')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('informativoacesso.input', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>  
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/informativoacesso/create.blade.php ENDPATH**/ ?>