<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Lista perfil x tela'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Lista perfil x tela</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">
                <strong>Lista perfil x tela </strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                <thead>
                <tr>
                    <th>Perfil</th>
                    <th>Status</th>
                    <th>Acessos</th>
                </tr>
                </thead>
                <tbody>
                    <?php if(count($PerfilTelas)>0): ?>
                        <?php $__currentLoopData = $PerfilTelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfiltela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($perfiltela->Perfil); ?></td>
                                <td>
                                    <?php if($perfiltela->PerfilTelaStatus == 1): ?>
                                        Ativo
                                    <?php elseif($perfiltela->PerfilTelaStatus == 2): ?>
                                        Inativo
                                    <?php else: ?>
                                        Bloqueado
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('perfiltela/editar/'.$perfiltela->PerfilID)); ?>">Alterar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="3">Nenhum Perfil Tela Cadastrado</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
            <div class="form-group">
                <form role="form" method="get" action="<?php echo e(action('PerfilTelaController@index')); ?>">
                    <button type="submit" class="btn btn-primary">NOVO</button>
                </form>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>

    <script src="<?php echo e(url('js/plugins/dataTables/datatables.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <!-- Page-Level Scripts -->
    <script>

        // Upgrade button class name
        $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                language: {
                    url: "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Portuguese-Brasil.json"
                },
                
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'PerfilTela'},
                    {extend: 'pdf', title: 'PerfilTela'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

        });

    </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/perfiltela/show.blade.php ENDPATH**/ ?>