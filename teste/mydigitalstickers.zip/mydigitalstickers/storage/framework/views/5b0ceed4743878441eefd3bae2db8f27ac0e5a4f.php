<?php $__env->startSection('title', 'Cadastro de faixas eventos'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col-lg-10">
    <h2>Cadastro de faixas eventos</h2>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('eventoescola.list')); ?>">Lista eventos da escola</a>
        </li>
        <li class="breadcrumb-item active">
            <strong>Cadastro de faixas eventos</strong>
        </li>
    </ol>
</div>
<div class="col-lg-2">

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form role="form" method="post" action="<?php echo e(url('eventoescola/eventofaixa/faixagravar/'.$Dados[0]->EventoEscolaID)); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <fieldset disabled>
                    <div class="form-group">
                        <label for="RedeID">Rede</label>
                        <?php if(count($Dados)>0): ?>
                            <?php $__currentLoopData = $Dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="text" class="form-control" value="<?php echo e($Dado->Rede); ?>">
                            <input type="hidden" class="form-control" name="EventoEscolaID" value="<?php echo e($Dado->EventoEscolaID); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="validationCustom01">Escola</label>
                        <?php if(count($Dados)>0): ?>
                            <?php $__currentLoopData = $Dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="text" class="form-control" value="<?php echo e($Dado->Escola); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="validationCustom01">Evento</label>
                        <?php if(count($Dados)>0): ?>
                            <?php $__currentLoopData = $Dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="text" class="form-control" value="<?php echo e($Dado->Evento); ?>">                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </fieldset>
                <hr>
                <div class="form-group">
                    <h2 id="content">Parâmetros - Faixa</h2>
                    <div class="form-group">
                        <a id="Data" href="#">Data </a> /
                        <a id="Numero" href="#">Número </a>
                    </div>
                    <div style="display: none" id="ParamDataIni" class="form-group">
                        <label for="DataFIm">Data Ini</label>
                        <div class="input-group " id="calendarioIni">
                            <input type="date" class="form-control" name="FaixaEventoDTIni" placeholder="dd/mm/aaaa" id="validationCustom01">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-th"></span>
                            </div>
                        </div>
                    </div>
                    <div style="display: none" id="ParamDataFim" class="form-group">
                        <label for="DataFIm">Data Fim</label>
                        <div class="input-group " id="calendarioFim">
                            <input type="date" class="form-control" name="FaixaEventoDTFim" placeholder="dd/mm/aaaa" id="validationCustom01">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-th"></span>
                            </div>
                        </div>
                    </div>
                    <div id="ParamNumIni" class="form-group">
                        <label for="DataFIm">Num Ini</label>
                        <input type="number" class="form-control" name="FaixaEventoNumIni" min="1" max="100" />
                    </div>
                    <div id="ParamNumFim" class="form-group">
                        <label for="DataFIm">Num Fim</label>
                        <input type="number" class="form-control" name="FaixaEventoNumFim" min="1" max="100" />
                    </div>
                    <hr><br>
                </div>
                <div class="form-group">
                    <label for="DataFIm">Pontuação</label>
                    <input type="number" class="form-control" name="FaixaEventoPontoQuantidade" min="1" max="100" />
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
        $(document).ready(function(){
            $("#Data").click(function(){
                $("#ParamDataIni").show();
                $("#ParamDataFim").show();
                $("#ParamNumIni").hide();
                $("#ParamNumFim").hide();
            });
            $("#Numero").click(function(){
                $("#ParamDataIni").hide();
                $("#ParamDataFim").hide();
                $("#ParamNumIni").show();
                $("#ParamNumFim").show();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/eventoescola/faixanew.blade.php ENDPATH**/ ?>