

<?php $__env->startSection('title', 'Editar Tradução'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Tradução</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('traducao.list')); ?>">Lista Tradução </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar Tradução</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form role="form" method="post" action="<?php echo e(url('traducao/update/'.$traducao->TraducaoID)); ?>">
    <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="validationCustom01">Br</label>
                <input type="text" class="form-control" name="TraducaoTextoBr" id="validationCustom01" required <?php if(isset($traducao)): ?>value="<?php echo e(old('', $traducao->TraducaoTextoBr)); ?>"<?php endif; ?>  />
            </div>
            <div class="form-group">
                <label for="validationCustom01">Us</label>
                <input type="text" class="form-control" name="TraducaoTextoUs" id="validationCustom01" <?php if(isset($traducao)): ?>value="<?php echo e(old('', $traducao->TraducaoTextoUs)); ?>"<?php endif; ?> />
            </div>
            <div class="form-group">
                <label for="validationCustom01">Es</label>
                <input type="text" class="form-control" name="TraducaoTextoEs" id="validationCustom01" <?php if(isset($traducao)): ?>value="<?php echo e(old('', $traducao->TraducaoTextoEs)); ?>"<?php endif; ?> />
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/traducao/editar.blade.php ENDPATH**/ ?>