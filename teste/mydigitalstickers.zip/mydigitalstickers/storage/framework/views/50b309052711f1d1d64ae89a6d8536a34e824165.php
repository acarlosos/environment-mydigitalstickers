<?php $__env->startSection('title', 'Editar compra'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar compra</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('alunocompra.list')); ?>">Lista compra</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar compra</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('alunocompra/update/'.$alunocompra->AlunoCompraID)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="UsuarioEscolaID">Nome Usuario</label>
                <select class="form-control" name="UsuarioEscolaID">
                    <?php $__currentLoopData = $alunocompra->UsuarioEscola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($UsuarioEscola->UsuarioEscolaID == $alunocompra->UsuarioEscolaID): ?> selected <?php endif; ?> value="<?php echo e($UsuarioEscola->UsuarioEscolaID); ?>">
                            <?php echo e($UsuarioEscola->UsuarioNome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="validationCustom01">Quantia de Pontos</label>
                <input type="text" class="form-control" name="AlunoCompraQuantidade" id="validationCustom01" required <?php if(isset($alunocompra)): ?>value="<?php echo e(old('', $alunocompra->AlunoCompraQuantidade)); ?>"<?php endif; ?> placeholder="Pontos" />
                <div class="valid-feedback">Tudo certo!</div>
            </div>
            <div class="form-group">
                <label for="AlunoCompras">Status</label>
                <select class="form-control" name="AlunoCompraStatus">
                    <option value="1" <?php if(isset($alunocompra) && $alunocompra->AlunoCompraStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                    <option value="2" <?php if(isset($alunocompra) && $alunocompra->AlunoCompraStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                    <option value="3" <?php if(isset($alunocompra) && $alunocompra->AlunoCompraStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                            <?php if(isset($alunocompra->AlunoCompraDTAtivacao) && $alunocompra->AlunoCompraDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($alunocompra->AlunoCompraDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/alunocompra/editar.blade.php ENDPATH**/ ?>