

<?php $__env->startSection('title', 'Editar Ponto'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Ponto</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('ponto.list')); ?>">Lista Ponto </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar Ponto</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bd-example">
        <form role="form" method="post" action="<?php echo e(url('ponto/update/'.$ponto->PontoID)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="UsuarioEscolaID">Usuario Escola</label>
                <select class="form-control" name="UsuarioEscolaID">
                    <?php $__currentLoopData = $ponto->UsuarioEscola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($UsuarioEscola->UsuarioEscolaID == $ponto->UsuarioEscolaID): ?> 
                        selected <?php endif; ?> value ="<?php echo e($UsuarioEscola->UsuarioEscolaID); ?>">
                        <?php echo e($UsuarioEscola->Escola.' - '.$UsuarioEscola->UsuarioNome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="validationCustom01">Pontos</label>
                <input type="text" class="form-control" name="PontoQuantidade" id="validationCustom01" required <?php if(isset($ponto)): ?>value="<?php echo e(old('', $ponto->PontoQuantidade)); ?>"<?php endif; ?> placeholder="Pontos" />
            </div>
            <div class="form-group">
                <label for="Pontos">Status</label>
                <select class="form-control" name="PontoStatus">
                    <option value="1" <?php if(isset($ponto) && $ponto->PontoStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                    <option value="2" <?php if(isset($ponto) && $ponto->PontoStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                    <option value="3" <?php if(isset($ponto) && $ponto->PontoStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                            <?php if(isset($ponto->PontoDTAtivacao) && $ponto->PontoDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($ponto->PontoDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                            <?php if(isset($ponto->PontoDTInativacao) && $ponto->PontoDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($ponto->PontoDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                            <?php if(isset($ponto->PontoDTBloqueio) && $ponto->PontoDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($ponto->PontoDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
    <script>
            $("#campoCelular").mask("(99) 09999-9999");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/ponto/editar.blade.php ENDPATH**/ ?>