

<?php $__env->startSection('title', __('Página não encontrada')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message'); ?>
    <p>
        Página não encontrada<br />
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/errors/404.blade.php ENDPATH**/ ?>