<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Editar eventos da escola'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar eventos da escola</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('eventoescola.list')); ?>">Lista eventos da escola</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar eventos da escola</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('eventoescola/update/'.$EventoEscolas['IDS'][0]->EscolaID)); ?>">
            <?php echo csrf_field(); ?>
            <div class="bd-example">
                <div class="form-group">
                    <label for="EscolaID">Escola</label>
                    <div class="form-group">
                        <select class="form-control" name="EscolaID">
                                <option value="<?php echo e($EventoEscolas['IDS'][0]->EscolaID); ?>"><?php echo e($EventoEscolas['IDS'][0]->Escola); ?></option>
                        </select>
                    </div>                  
                </div>
                <div class="form-group">
                    <label for="EventoID">Evento</label>
                    <div class="form-check">
                        <?php $__currentLoopData = $EventoEscolas['Eventos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="i-checks">
                                <label>
                                    <input type="checkbox" class="form-check-input" name="EventoID[<?php echo e($Evento->EventoID); ?>]" value="<?php echo e($Evento->EventoID); ?>"
                                    <?php if(isset($EventoEscolas[0]) && count($EventoEscolas[0]) > 0): ?>
                                        <?php $__currentLoopData = $EventoEscolas[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $EventoEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Evento->EventoID == $EventoEscola->EventoID): ?> checked <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    ><i></i> <?php echo e($Evento->Evento); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('js/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/eventoescola/editar.blade.php ENDPATH**/ ?>