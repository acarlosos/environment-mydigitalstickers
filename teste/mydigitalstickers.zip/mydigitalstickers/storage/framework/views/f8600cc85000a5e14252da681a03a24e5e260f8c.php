<?php $__env->startSection('title', 'Editar escola'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar escola</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('escola.list')); ?>">Lista escola / Parâmetros</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar escola</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('escola/update/'.$escola->EscolaID)); ?>">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="RedeID">Rede</label>
                    <select class="form-control" name="RedeID">
                        <?php $__currentLoopData = $escola->Rede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Rede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($Rede->RedeID == $escola->RedeID): ?> selected <?php endif; ?> value="<?php echo e($Rede->RedeID); ?>"><?php echo e($Rede->Rede); ?></option>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Nome da Escola</label>
                    <input type="text" class="form-control" name="Escola" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->Escola)); ?>"<?php endif; ?> placeholder="Name" />
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Cod. Escola</label>
                    <input type="text" class="form-control" name="EscolaCod" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaCod)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Senha Escola</label>
                    <input type="text" class="form-control" name="EscolaSenha" />
                </div>
                <div class="form-group">
                    <label for="exampleInpvalidationCustom01utEmail1">Escola CNPJ</label>
                    <input type="text" class="form-control" name="EscolaCNPJ" id="campoCNPJ" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaCNPJ)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Valor Fixo</label>
                    <input type="text" class="form-control" name="EscolaValorFixo" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaValorFixo)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Valor Vaviável</label>
                    <input type="text" class="form-control" name="EscolaValorVaviavel" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaValorVaviavel)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Dia Vencimento</label>
                    <input type="number" class="form-control" name="EscolaDiaVencimento" min="1" max="30" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaDiaVencimento)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Data Expiração</label>
                    <div class="input-group " id="control" >
                        <input type="date" class="form-control" name="EscolaDTExpiracao" id="validationCustom01" required placeholder="dd/mm/aaaa" value="<?php echo e($escola->EscolaDTExpiracao ? $escola->EscolaDTExpiracao->format('Y-m-d') : ''); ?>" />
                        <div class="valid-feedback">Tudo certo!</div>
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Telefone</label>
                    <input type="text" id="campoTelefone" class="form-control" name="EscolaTelefone" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaTelefone)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="validationCustom01">Celular</label>
                    <input type="text" class="form-control" name="EscolaCelular" id="campoCelular" id="validationCustom01" required <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaCelular)); ?>"<?php endif; ?> />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Chave Pix</label>
                    <input type="text" class="form-control" id="campoCelularPix" name="EscolaCelularPix"  <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaCelularPix)); ?>"<?php endif; ?> />
                </div>
                <div class="form-group">
                    <label for="Status">Status</label>
                    <select class="form-control" name="EscolaStatus">
                        <option value="1" <?php if(isset($escola) && $escola->EscolaStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                        <option value="2" <?php if(isset($escola) && $escola->EscolaStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                        <option value="3" <?php if(isset($escola) && $escola->EscolaStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                        <option value="4" <?php if(isset($escola) && $escola->EscolaStatus == 4): ?>selected <?php endif; ?>>Prospect</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Motivo Bloqueio</label>
                    <input type="text" class="form-control" name="EscolaMotivoBloqueio"  <?php if(isset($escola)): ?>value="<?php echo e(old('', $escola->EscolaMotivoBloqueio)); ?>"<?php endif; ?> />
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
                <fieldset disabled>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Cadastro:   --/--/---- 00:00:00"
                                   <?php if(isset($escola->EscolaDTCadastro) && $escola->EscolaDTCadastro != ''): ?> value="Data Cadastro: <?php echo e(\Carbon\Carbon::parse($escola->EscolaDTCadastro)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                                   <?php if(isset($escola->EscolaDTAtivacao) && $escola->EscolaDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($escola->EscolaDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                                   <?php if(isset($escola->EscolaDTInativacao) && $escola->EscolaDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($escola->EscolaDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                                   <?php if(isset($escola->EscolaDTBloqueio) && $escola->EscolaDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($escola->EscolaDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
    <script>
        $("#campoTelefone").mask("(99) 9999-9999");
        $("#campoCelular").mask("(99) 09999-9999");
        $("#campoCNPJ").mask("99.999.999/9999-99");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/escola/editar.blade.php ENDPATH**/ ?>