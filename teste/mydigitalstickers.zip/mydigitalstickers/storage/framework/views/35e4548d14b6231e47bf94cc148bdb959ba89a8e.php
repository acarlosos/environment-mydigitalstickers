

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('title', 'Editar Usuario Escola Informativo Acesso'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Usuario Escola Informativo Acesso</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('usuarioescolainformativoacesso.list')); ?>">Usuario Escola Informativo Acesso</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar Usuario Escola Informativo Acesso</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="bd-example">
            <form role="form" method="post" action="<?php echo e(url('usuarioescolainformativoacesso/update/'.$usuarioescolainformativoacesso->UsuarioEscolaInformativoAcessoID)); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="UsuarioEscolaID">Usuario Escola</label>
                    <select class="form-control" name="UsuarioEscolaID">
                        <?php $__currentLoopData = $usuarioescolainformativoacesso->UsuarioEscola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($UsuarioEscola->UsuarioEscolaID == $usuarioescolainformativoacesso->UsuarioEscolaID): ?> selected <?php endif; ?> value ="<?php echo e($UsuarioEscola->UsuarioEscolaID); ?>">
                            <?php echo e($UsuarioEscola->Escola.' - '.$UsuarioEscola->UsuarioNome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Data Ativação</label>
                    <div class="input-group " id="control" >
                        <input type="date" class="form-control" name="UsuarioEscolaInformativoAcessoIDDTAtivacao" placeholder="dd/mm/aaaa" value="<?php echo e($usuarioescolainformativoacesso->UsuarioEscolaInformativoAcessoIDDTAtivacao ? $usuarioescolainformativoacesso->UsuarioEscolaInformativoAcessoIDDTAtivacao->format('Y-m-d') : ''); ?>" />
                        <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="UsuarioEscolaInformativoAcessos">Acesso</label>
                    <select class="form-control" name="UsuarioEscolaInformativoAcesso">
                        <option value="1" <?php if(isset($usuarioescolainformativoacesso) && $usuarioescolainformativoacesso->UsuarioEscolaInformativoAcesso == 1): ?>selected <?php endif; ?>>Aprovado</option>
                        <option value="2" <?php if(isset($usuarioescolainformativoacesso) && $usuarioescolainformativoacesso->UsuarioEscolaInformativoAcesso == 2): ?>selected <?php endif; ?>>Não Aprovado</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
            </form>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
        <script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuarioescolainformativoacesso/editar.blade.php ENDPATH**/ ?>