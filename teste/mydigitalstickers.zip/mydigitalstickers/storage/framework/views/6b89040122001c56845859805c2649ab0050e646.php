<?php $__env->startSection('title', 'Editar Usuário Aluno'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Usuário Aluno</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('usuario.list')); ?>">Lista Usuário</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar Usuário Aluno</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('usuario/updatealuno/'.$usuario->UsuarioID)); ?>">
            <?php echo csrf_field(); ?>
            <fieldset disabled>
                <div class="form-group">
                    <label for="exampleInputEmail1">Login do Usuario</label>
                    <input type="text" class="form-control" name="UsuarioLogin" <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioLogin)); ?>"<?php endif; ?> placeholder="Usuario" />
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Nome do Usuario</label>
                    <input type="text" class="form-control" name="UsuarioNome" <?php if(isset($usuario)): ?>value="<?php echo e(old('', $usuario->UsuarioNome)); ?>"<?php endif; ?> />
                </div>
            </fieldset>
            <div class="form-group">
                <label for="validationCustom01">Senha do Usuario</label>
                <input type="text" class="form-control" name="UsuarioSenha" id="validationCustom01" required/>
            </div>
            <div class="form-group">
                <label for="validationCustom01">Confirmar Senha do Usuario</label>
                <input type="text" class="form-control" name="ConfirmarUsuarioSenha" id="validationCustom01" required/>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1"><b>Foto Usuario</b></label>
                <input type="file" class="form-control-file" name="image" id="image">
                <label for="exampleInputPassword1">Tamanho Máximo 25KB </label>
            </div>
            <div class="form-group">
                <img src="<?php echo asset('storage/usuario'.$usuario->UsuarioID.'.png'); ?>">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTAtivacao) && $usuario->UsuarioDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTInativacao) && $usuario->UsuarioDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                               <?php if(isset($usuario->UsuarioDTBloqueio) && $usuario->UsuarioDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($usuario->UsuarioDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuario/editaraluno.blade.php ENDPATH**/ ?>