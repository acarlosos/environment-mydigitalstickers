
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Cadastrar Usuário Escola'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Cadastrar Usuário Escola</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('usuarioescola.list')); ?>">Lista Usuário Escola</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Cadastrar Usuário Escola</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form role="form" method="post" action="<?php echo e(action('UsuarioEscolaController@store')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="EscolaID">Escolas</label>
                <select class="form-control" name="EscolaID">
                    <?php $__currentLoopData = $Dados->EscolaID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Escola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($Escola->EscolaID); ?>"><?php echo e($Escola->Escola); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="UsuarioID">Usuarios</label>
                
                    <?php $__currentLoopData = $Dados->UsuarioNome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="i-checks">
                            <label>
                                <input type="checkbox" name="UsuarioNome[<?php echo e($Usuario->UsuarioID); ?>]" value="<?php echo e($Usuario->UsuarioID); ?>">
                                <i></i><?php echo e($Usuario->UsuarioNome); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group">
                    <label for="Status">Status</label>
                    <select class="form-control" name="UsuarioEscolaStatus">
                        <option value="1">Ativo</option>
                    </select>
            </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>

            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação: --/--/---- 00:00:00">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00">
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('js/plugins/iCheck/icheck.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuarioescola/usuarioescola.blade.php ENDPATH**/ ?>