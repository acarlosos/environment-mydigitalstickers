<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Cadastro de eventos da escola'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Cadastro de eventos da escola</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('eventoescola.list')); ?>">Lista eventos da escola</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Cadastro de eventos da escola</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(action('EventoEscolaController@store')); ?>">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="EscolaID">Escola</label>
                    <select class="form-control" name="EscolaID">
                        <?php $__currentLoopData = $Dados->EscolaID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Escola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($Escola->EscolaID); ?>"><?php echo e($Escola->Escola); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="EventoID">Evento</label>
                    <div class="form-check">
                        <?php $__currentLoopData = $Dados->EventoID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="i-checks">
                            <label>
                                <input type="checkbox" class="form-check-input" name="EventoID[<?php echo e($Evento->EventoID); ?>]" value="<?php echo e($Evento->EventoID); ?>" />
                               <i></i> <?php echo e($Evento->Evento); ?>

                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <input type="hidden" class="form-check-input" name="EventoStatus" value="1">
                </div>
                <div class="form-group">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">OK</button>
                    </div>
                </div>
        </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('js/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/eventoescola/eventoescola.blade.php ENDPATH**/ ?>