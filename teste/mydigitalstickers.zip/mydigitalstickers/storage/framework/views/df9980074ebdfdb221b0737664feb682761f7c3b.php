<?php $__env->startSection('title', 'Editar rede'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar rede</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('rede.list')); ?>">Lista rede </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar rede</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form role="form" method="post" action="<?php echo e(url('rede/update/'.$rede->RedeID)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="validationCustom01">Nome da Rede</label>
                <input type="text" class="form-control" name="Rede" id="validationCustom01" required <?php if(isset($rede)): ?>value="<?php echo e(old('', $rede->Rede)); ?>"<?php endif; ?> placeholder="Name" />
            </div>
            <div class="form-group">
                <div class="form-group">
                    <label for="validationCustom01">Cod. Rede</label>
                    <input type="text" class="form-control" name="RedeCod" id="validationCustom01" required <?php if(isset($rede)): ?>value="<?php echo e(old('', $rede->RedeCod)); ?>"<?php endif; ?> placeholder="Cod." />
                </div>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Moeda da Rede</label>
                <input type="text" class="form-control" name="RedeNomeMoeda" placeholder="Name" <?php if(isset($rede)): ?>value="<?php echo e(old('', $rede->RedeNomeMoeda)); ?>"<?php endif; ?>>
            </div>
            <div class="form-group">
                <label for="Status">Status</label>
                <select class="form-control" name="RedeStatus">
                    <option value="1" <?php if(isset($rede) && $rede->RedeStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                    <option value="2" <?php if(isset($rede) && $rede->RedeStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                    <option value="3" <?php if(isset($rede) && $rede->RedeStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                                <?php if(isset($rede->RedeDTAtivacao) && $rede->RedeDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($rede->RedeDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                               <?php if(isset($rede->RedeDTInativacao) && $rede->RedeDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($rede->RedeDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                               <?php if(isset($rede->RedeDTBloqueio) && $rede->RedeDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($rede->RedeDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/rede/editar.blade.php ENDPATH**/ ?>