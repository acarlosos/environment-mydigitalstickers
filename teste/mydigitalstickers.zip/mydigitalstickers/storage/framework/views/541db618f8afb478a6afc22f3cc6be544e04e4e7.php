

<?php $__env->startSection('title', __('Erro interno')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message'); ?>
    <p>
        Houve um erro interno.<br />
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/errors/500.blade.php ENDPATH**/ ?>