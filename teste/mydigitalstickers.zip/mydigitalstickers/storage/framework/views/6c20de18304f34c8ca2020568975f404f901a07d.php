<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Lista log informativo de acesso'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Lista log informativo de acesso</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">
                <strong>Lista log informativo de acesso</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Data Ativação</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($UsuarioEscolaInformativoAcessos)>0): ?>
                            <?php $__currentLoopData = $UsuarioEscolaInformativoAcessos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarioescolainformativoacesso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($usuarioescolainformativoacesso->Usuario); ?></td>
                                    <td><?php echo e($usuarioescolainformativoacesso->UsuarioEscolaInformativoAcessoIDDTAtivacao->format('d/m/Y')); ?></td>
                                    <td>
                                        <?php if($usuarioescolainformativoacesso->UsuarioEscolaInformativoAcesso == 1): ?>
                                            Aprovado
                                        <?php else: ?>
                                            Não Aprovado
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">Nenhum cadastrado</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>

    <script src="<?php echo e(url('js/plugins/dataTables/datatables.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <!-- Page-Level Scripts -->
    <script>

        // Upgrade button class name
        $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                language: {
                    url: "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Portuguese-Brasil.json"
                },
                
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'UsuarioEscolaEscolaInforamtivoAcesso'},
                    {extend: 'pdf', title: 'UsuarioEscolaEscolaInforamtivoAcesso'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

        });

        $(".campoCNPJ").mask("99.999.999/9999-99");
    </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuarioescolainformativoacesso/show.blade.php ENDPATH**/ ?>