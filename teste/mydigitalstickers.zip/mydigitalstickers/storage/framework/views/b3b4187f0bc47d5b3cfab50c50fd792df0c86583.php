<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Lista escola / Parâmetros'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Lista escola / Parâmetros</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">
                <strong>Lista escola / Parâmetros</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="table-responsive">
                <?php
                    $AcessoCad = app(\App\Http\Controllers\EscolaController::class)->permissaoAcesso(app('request'));
                ?>
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                        <tr>
                            <th>Escola</th>
                            <th>Cod. Escola</th>
                            <th>Escola CNPJ</th>
                            <th>Rede</th>
                            <th>Status</th>
                            <?php $__currentLoopData = $AcessoCad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AcessoCadItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($AcessoCadItem->Tela): ?>
                                    <th>Dados da Escola</th>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Parâmetros</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(count($Escolas)>0): ?>
                        <?php $__currentLoopData = $Escolas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($escola->Escola); ?></td>
                                <td><?php echo e($escola->EscolaCod); ?></td>
                                <td class="campoCNPJ"><?php echo e($escola->EscolaCNPJ); ?></td>
                                <td><?php echo e($escola->Rede); ?></td>
                                <td>
                                    <?php if($escola->EscolaStatus == 1): ?>
                                        Ativo
                                    <?php elseif($escola->EscolaStatus == 2): ?>
                                        Inativo
                                    <?php elseif($escola->EscolaStatus == 3): ?>
                                        Bloqueado
                                    <?php else: ?>
                                        Prospect
                                    <?php endif; ?>
                                </td>
                                <?php $__currentLoopData = $AcessoCad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AcessoCadItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($AcessoCadItem->Tela): ?>
                                        <td>
                                            <a href="<?php echo e(url('escola/editar/'.$escola->EscolaID)); ?>">Alterar</a>
                                        </td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td>
                                    <a href="<?php echo e(url('escola/editarparams/'.$escola->EscolaID)); ?>">Alterar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">Nenhuma Escola Cadastrada</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
            <?php $__currentLoopData = $AcessoCad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AcessoCadItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($AcessoCadItem->Tela): ?>
                    <div class="form-group">
                        <form role="form" method="get" action="<?php echo e(action('EscolaController@index')); ?>">
                            <button type="submit" class="btn btn-primary">NOVO</button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>

    <script src="<?php echo e(url('js/plugins/dataTables/datatables.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <!-- Page-Level Scripts -->
    <script>

        // Upgrade button class name
        $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                language: {
                    url: "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Portuguese-Brasil.json"
                },
                
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'Escolas'},
                    {extend: 'pdf', title: 'Escolas'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

        });

        $(".campoCNPJ").mask("99.999.999/9999-99");
    </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/escola/show.blade.php ENDPATH**/ ?>