<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Editar perfil x tela'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar Perfil Tela</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('perfiltela.list')); ?>">Lista perfil x tela </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar perfil x tela</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(url('perfiltela/update/'.$PerfilTelas['IDS'][0]->PerfilID)); ?>">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="PerfilID">Perfil</label>
                    <select class="form-control">
                        <option selected><?php echo e($PerfilTelas['IDS'][0]->Perfil); ?>

                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="TelaID">Tela</label>
                    <div class="form-check">
                        
                        <?php $__currentLoopData = $PerfilTelas['Telas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Tela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="i-checks">
                                <label>
                                    <input type="checkbox" class="form-check-input" name="TelaID[<?php echo e($Tela->TelaID); ?>]" value="<?php echo e($Tela->TelaID); ?>"
                                    <?php if(isset($PerfilTelas[0]) && count($PerfilTelas[0]) > 0): ?>
                                        <?php $__currentLoopData = $PerfilTelas[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PerfilTela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Tela->TelaID == $PerfilTela->TelaID): ?> checked <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    >
                                    <i></i> <?php echo e($Tela->Tela); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Status">Status</label>
                    <select class="form-control" name="PerfilTelaStatus">
                        <option value="1" <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaStatus) && $PerfilTelas['IDS'][0]->PerfilTelaStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                        <option value="2" <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaStatus) && $PerfilTelas['IDS'][0]->PerfilTelaStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                        <option value="3" <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaStatus) && $PerfilTelas['IDS'][0]->PerfilTelaStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
                <fieldset disabled>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                                <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaDTAtivacao) && $PerfilTelas['IDS'][0]->PerfilTelaDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($PerfilTelas['IDS'][0]->PerfilTelaDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                                <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaDTInativacao) && $PerfilTelas['IDS'][0]->PerfilTelaDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($PerfilTelas['IDS'][0]->PerfilTelaDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                                <?php if(isset($PerfilTelas['IDS'][0]->PerfilTelaDTBloqueio) && $PerfilTelas['IDS'][0]->PerfilTelaDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($PerfilTelas['IDS'][0]->PerfilTelaDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                        </div>
                    </div>
                </fieldset>
        </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('js/plugins/iCheck/icheck.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/perfiltela/editar.blade.php ENDPATH**/ ?>