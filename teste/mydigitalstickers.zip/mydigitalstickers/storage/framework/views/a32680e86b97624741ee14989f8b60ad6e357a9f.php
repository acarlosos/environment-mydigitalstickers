<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Importação de Alunos'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="col-lg-10">
        <h2>Importação de Alunos</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('usuario.list')); ?>">Lista usuario</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Importação de Alunos</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <?php if(session('erro')): ?>
            <div class="alert-danger">
                <?php echo e(session('erro')); ?>

            </div>
        <?php endif; ?>
        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <form role="form" method="post" enctype="multipart/form-data" action="<?php echo e(url('usuario/alunoimport')); ?>">
            <?php echo e(csrf_field()); ?>

            <h4 for="exampleInputPassword1">Importar Alunos</h4>
            <input type="file" class="form-control-file" name="importcsv" id="importcsv" required>
            <br>
            <hr>
            <div class="form-group">
                <h6 for="exampleInputPassword1">Formato CSV, primeiro dado <b>Usuario do Aluno</b>, segundo dado <b>Senha do Aluno</b>
                    e terceiro dado <b>Nome do Aluno</b>.<br>
                    - Os dados devem ser separados por ponto e vírgula (;)</h6><br><br>
                <h6 for="exampleInputPassword1">Exemplo<br><b>UsuarioLogin;UsuarioSenha;UsuarioNome</b><br>
                    LoginAluno;SenhaAluno;Nome do Aluno
                </h6>
            </div>
            <hr>
            <button type="submit" class="btn btn-primary">Importar</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
    <script src="<?php echo e(url('js/plugins/dataTables/datatables.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <!-- Page-Level Scripts -->
    <script>

        // Upgrade button class name
        $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                language: {
                    url: "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Portuguese-Brasil.json"
                },

                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'EventoEscolas'},
                    {extend: 'pdf', title: 'EventoEscolas'},

                    {extend: 'print',
                        customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    }
                ]

            });

        });

        $(".campoCNPJ").mask("99.999.999/9999-99");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/usuario/alunoimport.blade.php ENDPATH**/ ?>