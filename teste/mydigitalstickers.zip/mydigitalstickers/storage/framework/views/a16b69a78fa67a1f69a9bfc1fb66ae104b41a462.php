<?php $__env->startSection('title', 'Tabela para tradução de idiomas'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Cadastrar tabela para tradução de idiomas</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('traducao.list')); ?>">Lista tabela para tradução de idiomas </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Cadastrar tabela para tradução de idiomas</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <form role="form" method="post" action="<?php echo e(action('TraducaoController@store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                    <label for="exampleInputEmail1">Br</label>
                    <input type="text" class="form-control" name="TraducaoTextoBr" id="validationCustom01" required >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Us</label>
                    <input type="text" class="form-control" name="TraducaoTextoUs" id="validationCustom01" >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Es</label>
                    <input type="text" class="form-control" name="TraducaoTextoEs" id="validationCustom01" >
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">OK</button>
                </div>
            </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/traducao/traducao.blade.php ENDPATH**/ ?>