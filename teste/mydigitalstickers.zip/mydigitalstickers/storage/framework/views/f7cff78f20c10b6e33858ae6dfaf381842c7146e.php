<?php $__env->startSection('title', 'Editar perfil'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Editar perfil </h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('perfil.list')); ?>">Lista perfil </a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Editar perfil </strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form role="form" method="post" action="<?php echo e(url('perfil/update/'.$perfil->PerfilID)); ?>">
    <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="validationCustom01">Nome do Perfil</label>
                <input type="text" class="form-control" name="Perfil" id="validationCustom01" required <?php if(isset($perfil)): ?>value="<?php echo e(old('', $perfil->Perfil)); ?>"<?php endif; ?> placeholder="Name" />
            </div>
            <div class="form-group">
                <div class="form-group">
                    <label for="validationCustom01">Cod. Perfil</label>
                    <input type="text" class="form-control" name="PerfilCod" id="validationCustom01" required <?php if(isset($perfil)): ?>value="<?php echo e(old('', $perfil->PerfilCod)); ?>"<?php endif; ?> placeholder="Cod." />
                    <div class="valid-feedback">Tudo certo!</div>
                </div>
            </div>
            <div class="form-group">
                <label for="Status">Status</label>
                <select class="form-control" name="PerfilStatus">
                    <option value="1" <?php if(isset($perfil) && $perfil->PerfilStatus == 1): ?>selected <?php endif; ?>>Ativo</option>
                    <option value="2" <?php if(isset($perfil) && $perfil->PerfilStatus == 2): ?>selected <?php endif; ?>>Inativo</option>
                    <option value="3" <?php if(isset($perfil) && $perfil->PerfilStatus == 3): ?>selected <?php endif; ?>>Bloqueado</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">OK</button>
            </div>
            <fieldset disabled>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00"
                               <?php if(isset($perfil->PerfilDTAtivacao) && $perfil->PerfilDTAtivacao != ''): ?> value="Data Ativação: <?php echo e(\Carbon\Carbon::parse($perfil->PerfilDTAtivacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Inativação:   --/--/---- 00:00:00"
                               <?php if(isset($perfil->PerfilDTInativacao) && $perfil->PerfilDTInativacao != ''): ?> value="Data Inativação: <?php echo e(\Carbon\Carbon::parse($perfil->PerfilDTInativacao)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Bloqueio:   --/--/---- 00:00:00"
                               <?php if(isset($perfil->PerfilDTBloqueio) && $perfil->PerfilDTBloqueio != ''): ?> value="Data Bloqueio: <?php echo e(\Carbon\Carbon::parse($perfil->PerfilDTBloqueio)->format('d/m/Y H:i:s')); ?> "<?php endif; ?>>
                    </div>
                </div>
            </fieldset>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/perfil/editar.blade.php ENDPATH**/ ?>