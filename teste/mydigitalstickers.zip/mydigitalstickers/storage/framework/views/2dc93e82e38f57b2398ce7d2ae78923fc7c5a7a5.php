<?php $__env->startSection('title', 'Compra'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Cadastrar Aluno Compra</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('alunocompra.list')); ?>">Lista compra</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Compra</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form role="form" method="post" action="<?php echo e(action('AlunoCompraController@store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="validationCustom01">Usuario Escola</label>
            <select class="form-control" name="UsuarioEscolaID" >
                <?php $__currentLoopData = $UsuarioEscolas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UsuarioEscola): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value ="<?php echo e($UsuarioEscola->UsuarioEscolaID); ?>">
                        <?php echo e($UsuarioEscola->UsuarioNome); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="validationCustom01">Pontos</label>
            <input type="text" class="form-control" name="AlunoCompraQuantidade"
                   id="validationCustom01" required>
            <div class="valid-feedback">Tudo certo!</div>
        </div>
        <div class="form-group">
            <label for="Status">Status</label>
            <select class="form-control" name="AlunoCompraStatus">
                <option value="1">Ativo</option>
            </select>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">OK</button>
        </div>
        <fieldset disabled>
            <div class="form-group row">
                <div class="col-sm-10">
                    <input type="text" id="disabledTextInput" class="form-control" placeholder="Data Ativação:   --/--/---- 00:00:00">
                </div>
            </div>
        </fieldset>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/alunocompra/alunocompra.blade.php ENDPATH**/ ?>