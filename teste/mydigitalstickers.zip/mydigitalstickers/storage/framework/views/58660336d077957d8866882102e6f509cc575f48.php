<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">

    <title>My Digital Stickers  - <?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(url('css/animate.css')); ?>" rel="stylesheet"> 
    <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <?php if(!isset($menu)): ?>
                            <?php
                                $nome = app(\App\Http\Controllers\HomeController::class)->telasLiberadas(app('request')) ;
                            ?>
                        <?php else: ?>
                            <?php $nome = $menu; ?>
                        <?php endif; ?>
                        <img alt="image" class="rounded-circle" src="img/profile_small.jpg"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="block m-t-xs font-bold"><?php echo e($nome[0]->UsuarioNome); ?></span>
                            <span class="text-muted text-xs block"><?php echo e($nome[0]->Perfil); ?><b class="caret"></b></span>
                            <?php if($nome[0]->Escola): ?>
                                <span class="text-muted text-xs block"><?php echo e($nome[0]->Escola); ?><b class="caret"></b></span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a class="dropdown-item" href="/logout">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        
                    </div>
                </li>
                <?php if(!isset($menu)): ?>
                    <?php
                        $menu = app(\App\Http\Controllers\HomeController::class)->telasLiberadas(app('request')) ;
                    ?>
                <?php endif; ?>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if('rede' == $menuItem->Tela): ?>
                        <li id="rede">
                            <a href="<?php echo e(route('rede.list')); ?>"><i class="fa fa-code-fork"></i> <span class="nav-label">Cadastro de rede</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('perfil' == $menuItem->Tela): ?>
                        <li id="perfil">
                            <a href="<?php echo e(route('perfil.list')); ?>"><i class="fa fa-id-card"></i> <span class="nav-label">Cadastro de perfil</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('informativoacesso' == $menuItem->Tela): ?>
                        <li id="informativoacesso">
                            <a href="<?php echo e(route('informativoacesso.list')); ?>"><i class="fa fa-plug"></i> <span class="nav-label">Cadastro informativo de acesso</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('tela' == $menuItem->Tela): ?>
                        <li id="tela">
                            <a href="<?php echo e(route('tela.list')); ?>"><i class="fa fa-window-maximize"></i> <span class="nav-label">Cadastro de tela</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('perfiltela' == $menuItem->Tela): ?>
                        <li id="perfiltela">
                            <a href="<?php echo e(route('perfiltela.list')); ?>"><i class="fa fa-window-restore"></i> <span class="nav-label">Associar perfil x tela</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('evento' == $menuItem->Tela): ?>
                        <li id="evento">
                            <a href="<?php echo e(route('evento.list')); ?>"><i class="fa fa-twitch"></i> <span class="nav-label">Cadastro de evento</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('traducao' == $menuItem->Tela): ?>
                        <li id="traducao">
                            <a href="<?php echo e(route('traducao.list')); ?>"><i class="fa fa-arrows-h"></i> <span class="nav-label">Tabela para tradução de idiomas</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('usuarioescolainformativoacesso' == $menuItem->Tela): ?>
                        <li id="usuarioescolainformativoacesso">
                            <a href="<?php echo e(route('usuarioescolainformativoacesso.list')); ?>"><i class="fa fa-user-circle"></i> <span class="nav-label">Log informativo de acesso</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('escola' == $menuItem->Tela): ?>
                        <li id="escola">
                            <a href="<?php echo e(route('escola.list')); ?>"><i class="fa fa-building"></i> <span class="nav-label">Cadastro de escola</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('eventoescola' == $menuItem->Tela): ?>
                        <li id="eventoescola">
                            <a href="<?php echo e(route('eventoescola.list')); ?>"><i class="fa fa-address-book"></i> <span class="nav-label">Cadastro de eventos da escola</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('usuario' == $menuItem->Tela): ?>
                        <li id="usuario">
                            <a href="<?php echo e(route('usuario.list')); ?>"><i class="fa fa-user-o"></i> <span class="nav-label">Cadastro de usuário</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('usuarioescola' == $menuItem->Tela): ?>
                        <li id="usuarioescola">
                            <a href="<?php echo e(route('usuarioescola.list')); ?>"><i class="fa fa-user-circle-o"></i> <span class="nav-label">Listar usuário por escola</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('ponto' == $menuItem->Tela): ?>
                        <li id="ponto">
                            <a href="<?php echo e(route('ponto.list')); ?>"><i class="fa fa-eercast"></i> <span class="nav-label">Ajustar pontos da escola</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('escolacarteira' == $menuItem->Tela): ?>
                        <li id="escolacarteira">
                            <a href="<?php echo e(route('escolacarteira.index')); ?>"><i class="fa fa-money"></i> <span class="nav-label">Extrato da escola</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('alunocompra' == $menuItem->Tela): ?>
                        <li id="alunocompra">
                            <a href="<?php echo e(route('alunocompra.list')); ?>"><i class="fa fa-drivers-license"></i> <span class="nav-label">Compra</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if('carteira' == $menuItem->Tela): ?>
                        <li id="carteira">
                            <a href="<?php echo e(route('carteira.index')); ?>"><i class="fa fa-money"></i> <span class="nav-label">Extrato do aluno</span></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </nav>
        <div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<!-- nav topo-->
				<nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
					<div class="navbar-header">
						<a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
						<form role="search" class="navbar-form-custom" action="search_results.html">
							<div class="form-group" style="display: none">
								<input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
							</div>
						</form>
					</div>
					<ul class="nav navbar-top-links navbar-right">
						<li>
							<span class="m-r-sm text-muted welcome-message"></span>
						</li>
                        <li class="dropdown">
							<a class="dropdown-toggle count-info" data-toggle="dropdown" href="#" style="display: none">
								<i class="fa fa-envelope"></i>  <span class="label label-warning">16</span>
							</a>
							<ul class="dropdown-menu dropdown-messages">
								<li>
									<div class="dropdown-messages-box">
										<a class="dropdown-item float-left" href="profile.html">
											<img alt="image" class="rounded-circle" src="img/a7.jpg">
										</a>
										<div class="media-body">
											<small class="float-right">46h ago</small>
											<strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
											<small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
										</div>
									</div>
								</li>
								<li class="dropdown-divider"></li>
								<li>
									<div class="text-center link-block">
										<a href="mailbox.html" class="dropdown-item">
											<i class="fa fa-envelope"></i> <strong>Read All Messages</strong>
										</a>
									</div>
								</li>
							</ul>
						</li>
						<li class="dropdown">
							<a class="dropdown-toggle count-info" data-toggle="dropdown" href="#" style="display: none">
								<i class="fa fa-bell"></i>  <span class="label label-primary">8</span>
							</a>
							<ul class="dropdown-menu dropdown-alerts">
								<li>
									<a href="mailbox.html" class="dropdown-item">
										<div>
											<i class="fa fa-envelope fa-fw"></i> You have 16 messages
											<span class="float-right text-muted small">4 minutes ago</span>
										</div>
									</a>
								</li>
								<li class="dropdown-divider"></li>
								<li>
									<div class="text-center link-block">
										<a href="notifications.html" class="dropdown-item">
											<strong>See All Alerts</strong>
											<i class="fa fa-angle-right"></i>
										</a>
									</div>
								</li>
							</ul>
						</li>


						<li>
							<a href="/logout    ">
								<i class="fa fa-sign-out"></i> Log out
							</a>
						</li>
					</ul>

				</nav>
				<!-- fim nav topo-->
			</div>
			
			<!-- breadcrumb -->
            <?php $__env->startSection('breadcrumb'); ?>
                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Buttons</h2>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.html">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a>UI Elements</a>
                            </li>
                            <li class="breadcrumb-item active">
                                <strong>Buttons</strong>
                            </li>
                        </ol>
                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
            <?php echo $__env->yieldSection(); ?>
            
			<!-- fim breadcrumb -->
        <div class="row wrapper wrapper-content animated fadeInRight">
          <!-- content -->
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-content p-md">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php $__env->startSection('content'); ?>
                            <h1> Teste 1234</h1>
                        <?php echo $__env->yieldSection(); ?>
                    </div>
                </div>
            </div>
		  <!-- fcontent -->
        </div>
        <div class="footer">
            <div class="float-right">

            </div>

        </div>

        </div>
        </div>


    <!-- Mainly scripts -->
    <script src="<?php echo e(url('js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            let parteUrl = window.location.href.split('/');
            let idLi = '#'+parteUrl[3];
            $(idLi).addClass('active');

            $(idLi +" ul").addClass('in');
        })
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH /home1/mydig568/mydigitalstickers/resources/views/layout/layout.blade.php ENDPATH**/ ?>