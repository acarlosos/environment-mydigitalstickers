<?php

namespace App\Http\Controllers;

use App\Usuario;
use App\UsuarioEscola;
use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests\Usuario\UsuarioCreate;
use App\Http\Requests\Usuario\UsuarioAlter;
use App\Http\Requests\Usuario\UsuarioAlterAluno;

class UsuarioController extends Controller
{
    public function index(Request $request)
    {
        if($request->session()->get('PerfilCod') != 'adm' && $request->session()->get('PerfilCod') != 'master'){
            $Perfis =DB::table('Perfil')
                ->select(
                    'Perfil.PerfilID',
                    'Perfil.Perfil'
                )
                ->whereNotIn('Perfil.PerfilCod', ['adm','master'])
                ->get()
            ;
        }
        else{
            $Perfis =DB::table('Perfil')
                ->select(
                    'Perfil.PerfilID',
                    'Perfil.Perfil'
                )
                ->get()
            ;
        }

        return view('usuario/usuario', compact('Perfis'));
    }

    public function create()
    {
        return view('usuario.create');
    }

    public function store(UsuarioCreate $request)
    {
        $validated = $request->validated();

        $usuario = new Usuario;
        $usuario->PerfilID = request('PerfilID');
        $usuario->UsuarioLogin = request('UsuarioLogin');
        $usuario->UsuarioSenha = sha1(request('UsuarioSenha'));
        $usuario->UsuarioNome = request('UsuarioNome');
        if(isset($request->UsuarioEmail) && $request->UsuarioEmail){
            $usuario->UsuarioEmail = request('UsuarioEmail');
        }
        if(isset($request->UsuarioCelular) && $request->UsuarioCelular){
            $usuario->UsuarioCelular = str_replace(["(",")"," ","-"],'',$request->UsuarioCelular);
        }
        if(isset($request->UsuarioMatricula) && $request->UsuarioMatricula){
            $usuario->UsuarioMatricula = request('UsuarioMatricula');
        }
        $usuario->UsuarioStatus = request('UsuarioStatus');
        $usuario->save();


        //*****Escola Usuario*****

        if($request->session()->get('EscolaID') > 0) {
            $usuarioescola = new UsuarioEscola;
            $usuarioescola->UsuarioEscolaStatus = 1;
            $usuarioescola->UsuarioID = $usuario->UsuarioID;
            $usuarioescola->EscolaID = $request->session()->get('EscolaID');
            $usuarioescola->save();
        }

        return redirect()->back()
            ->with('status', 'Usuário criado com sucesso!');
    }

    public function show()
    {
        $Usuarios = new Usuario;
        $Usuarios = Usuario::all();
    }

    public function list(Request $request)
    {
        if($request->session()->get('PerfilCod') == 'adm' || $request->session()->get('PerfilCod') == 'master'){
            $Usuarios =DB::table('Usuario')
                ->join('Perfil','Usuario.PerfilID', '=', 'Perfil.PerfilID')
                ->select(
                    'Usuario.UsuarioID',
                    'Usuario.UsuarioNome',
                    'Usuario.UsuarioLogin',
                    'Usuario.UsuarioStatus',
                    'Usuario.UsuarioDTAtivacao',
                    'Usuario.UsuarioDTInativacao',
                    'Usuario.UsuarioDTBloqueio',
                    'Usuario.UsuarioCelular',
                    'Usuario.UsuarioEmail',
                    'Usuario.UsuarioMatricula',
                    'Usuario.PerfilID',
                    'Perfil.PerfilCod',
                    'Perfil.Perfil'
                )
                ->get();
        }
        elseif($request->session()->get('PerfilCod') == 'secret_escola' && $request->session()->get('PerfilCod') == 'gestor_escola'){
            $escolaid = $request->session()->get('EscolaID');
            $Usuarios =DB::table('Usuario')
                ->join('Perfil','Usuario.PerfilID', '=', 'Perfil.PerfilID')
                ->join('UsuarioEscola','Usuario.UsuarioID', '=', 'UsuarioEscola.UsuarioID')
                ->select(
                    'Usuario.UsuarioID',
                    'Usuario.UsuarioNome',
                    'Usuario.UsuarioLogin',
                    'Usuario.UsuarioStatus',
                    'Usuario.UsuarioDTAtivacao',
                    'Usuario.UsuarioDTInativacao',
                    'Usuario.UsuarioDTBloqueio',
                    'Usuario.UsuarioCelular',
                    'Usuario.UsuarioEmail',
                    'Usuario.UsuarioMatricula',
                    'Usuario.PerfilID',
                    'Perfil.PerfilCod',
                    'Perfil.Perfil'
                )
                ->where('UsuarioEscola.EscolaID','=',$escolaid)
                ->get();
        }
        else{
            $usuarioid = $request->session()->get('UsuarioID');
            $Usuarios =DB::table('Usuario')
                ->join('Perfil','Usuario.PerfilID', '=', 'Perfil.PerfilID')
                ->join('UsuarioEscola','Usuario.UsuarioID', '=', 'UsuarioEscola.UsuarioID')
                ->select(
                    'Usuario.UsuarioID',
                    'Usuario.UsuarioNome',
                    'Usuario.UsuarioLogin',
                    'Usuario.UsuarioStatus',
                    'Usuario.UsuarioDTAtivacao',
                    'Usuario.UsuarioDTInativacao',
                    'Usuario.UsuarioDTBloqueio',
                    'Usuario.UsuarioCelular',
                    'Usuario.UsuarioEmail',
                    'Usuario.UsuarioMatricula',
                    'Usuario.PerfilID',
                    'Perfil.PerfilCod',
                    'Perfil.Perfil'
                )
                ->where('Usuario.UsuarioID','=',$usuarioid)
                ->get();
        }
        return view('usuario/show', compact('Usuarios'));
    }

    public function edit($UsuarioID, Request $request)
    {
        $usuario = Usuario::findOrFail($UsuarioID);

        if($request->session()->get('PerfilCod') != 'adm' && $request->session()->get('PerfilCod') != 'master'){
            $usuario['Perfil'] =DB::table('Perfil')
                ->select(
                    'Perfil.PerfilID',
                    'Perfil.Perfil'
                )
                ->whereNotIn('Perfil.PerfilCod', ['adm','master'])
                ->get()
            ;
        }
        else{
            $usuario['Perfil'] =DB::table('Perfil')
                ->select(
                    'Perfil.PerfilID',
                    'Perfil.Perfil'
                )
                ->get()
            ;
        }

        return view('usuario/editar', compact('usuario'));
    }

    public function editaraluno($UsuarioID)
    {
        $usuario = Usuario::findOrFail($UsuarioID);
        return view('usuario/editaraluno', compact('usuario'));

        
    }

    public function updatealuno(UsuarioAlterAluno $request, $id)
    {
        $validated = $request->validated();

        $usuario = new Usuario;

        $usuario = Usuario::findOrFail($id);

        if(isset($request->UsuarioSenha) && $request->UsuarioSenha){
            $usuario->UsuarioSenha = sha1(request('UsuarioSenha'));
        }

        // Define o valor default para a vari�vel que cont�m o nome da imagem
        $nameFile = null;

        // Verifica se informou o arquivo e se � v�lido
        if ($request->hasFile('image') && $request->file('image')->isValid()) {

            if($request->file('image')->getSize() > 25000)
                return redirect()
                    ->back()
                    ->with('erro', 'O Tamanho do Arquivo deve ser at� 25KB')
                    ->withInput();

            // Define um aleat�rio para o arquivo baseado no timestamps atual
            $name = 'usuario'.$id;

            // Recupera a extens�o do arquivo
            $extension = $request->image->extension();
            if($extension != 'png')
                return redirect()
                    ->back()
                    ->with('erro', 'O Formato do Arquivo deve ser .png')
                    ->withInput();

            // Define finalmente o nome
            $nameFile = "{$name}.{$extension}";

            // Faz o upload:
            $upload = $request->image->storeAs(null, $nameFile);

            // Verifica se N�O deu certo o upload (Redireciona de volta)
            if ( !$upload )
                return redirect()
                    ->back()
                    ->with('erro', 'Falha ao fazer upload')
                    ->withInput();
        }

        $usuario->save();
        return redirect()->back()
            ->with('status', 'Usuário alterado com sucesso!');

    }

    public function update(UsuarioAlter $request, $id)
    {
        $validated = $request->validated();

        $usuario = new Usuario;

        $usuario = Usuario::findOrFail($id);

        $usuario->PerfilID = request('PerfilID');
        $usuario->UsuarioLogin = request('UsuarioLogin');
        if(isset($request->UsuarioSenha) && $request->UsuarioSenha){
            $usuario->UsuarioSenha = sha1(request('UsuarioSenha'));
        }
        $usuario->UsuarioNome = request('UsuarioNome');
        if(isset($request->UsuarioEmail) && $request->UsuarioEmail){
            $usuario->UsuarioEmail = request('UsuarioEmail');
        }
        if(isset($request->UsuarioCelular) && $request->UsuarioCelular){
            $usuario->UsuarioCelular = str_replace(["(",")"," ","-"],'',$request->UsuarioCelular);
        }
        if(isset($request->UsuarioMatricula) && $request->UsuarioMatricula){
            $usuario->UsuarioMatricula = request('UsuarioMatricula');
        }
        $usuario->UsuarioStatus = request('UsuarioStatus');

        if($usuario->Usuariotatus == 1)
            $usuario->UsuarioDTAtivacao = date('Y-m-d H:i:s');

        if($usuario->UsuarioStatus == 2)
            $usuario->UsuarioDTInativacao = date('Y-m-d H:i:s');

        if($usuario->UsuarioStatus == 3)
            $usuario->UsuarioDTBloqueio = date('Y-m-d H:i:s');

        $usuario->save();
        return redirect()->back()
            ->with('status', 'Usuário alterado com sucesso!');


    }

    public function permissaoAcesso($request){

        $AcessoCad = DB::table('Usuario')
            ->join('Perfil','Perfil.PerfilID', '=', 'Usuario.PerfilID')
            ->join('PerfilTela','PerfilTela.PerfilID', '=', 'Perfil.PerfilID')
            ->leftjoin('Tela','Tela.TelaID', '=', 'PerfilTela.TelaID')
            ->where('Usuario.UsuarioID', '=', $request->session()->get('UsuarioID'))
            ->select(
                'Tela.Tela'
            )
            ->where('Tela.Tela', '=', 'cadusuario')
            ->get();

        //dd($Menu,$request->session()->get('UsuarioEmail'));

        return $AcessoCad;
    }


    public function formimport(Request $request)
    {

        return view('usuario/alunoimport');
    }

    public function alunoimport(Request $request)
    {
        $MsgSucesso = 'Alunos Importados!';
        $MsgErro = 'Nenhuma linha foi importada, favor verificar o arquivo CSV!';

        if ($request->file('importcsv')->isValid()) {

            // Recupera a extension do arquivo
            $extension = $request->importcsv->getClientMimeType();
            if($extension != "text/csv")
                return redirect()
                    ->back()
                    ->with('erro', 'O Formato do Arquivo deve ser .csv')
                    ->withInput();

            $csvFile = $request->importcsv;
            $file_handle = fopen($csvFile, 'r');
            while (!feof($file_handle)) {
                $line_of_text[] = fgetcsv($file_handle, 0, ';');
            }
            fclose($file_handle);
        }
        $count = 0;
        $lin = 0;

        foreach ($line_of_text as $linha) {
            if (isset($linha[0]) && $linha[0] != '' && isset($linha[1]) && $linha[1] != '' && isset($linha[2]) && $linha[2] != ''){
                if($lin > 0) {
                    if ($request->session()->get('EscolaID') > 0) {
                        $usuario = new Usuario;
                        $usuario->PerfilID = 1;
                        $usuario->UsuarioLogin = $linha[0];
                        $usuario->UsuarioSenha = sha1($linha[1]);
                        $usuario->UsuarioNome = $linha[2];
                        $usuario->UsuarioStatus = 1;
                        $usuario->save();

                        //*****Escola Usuario*****

                        $usuarioescola = new UsuarioEscola;
                        $usuarioescola->UsuarioEscolaStatus = 1;
                        $usuarioescola->UsuarioID = $usuario->UsuarioID;
                        $usuarioescola->EscolaID = $request->session()->get('EscolaID');
                        $usuarioescola->save();
                    } else {
                        return redirect()->back()
                            ->with('erro', 'Usuário deve estar relacionado a uma Escola');
                    }

                    if (isset($usuarioescola->UsuarioEscolaID) && $usuarioescola->UsuarioEscolaID > 1) {
                        $count++;
                    }
                }
                $lin++;
            }
        }
        if($count > 0){
            return redirect()->back()
                ->with('status', $MsgSucesso);
        }
        else{
            return redirect()->back()
                ->with('erro', $MsgErro);
        }
    }


}
