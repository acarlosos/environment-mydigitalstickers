@extends('errors::minimal')

@section('title', __('Página não encontrada'))
@section('code', '404')
@section('message')
    <p>
        Página não encontrada<br />
    </p>
@endsection