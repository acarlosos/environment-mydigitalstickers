@extends('layout.layout')

@section('title', 'Home')

@section('breadcrumb')
@endsection

@section('content')
    <h1>
        Seja bem-vindo!
    </h1>
@endsection